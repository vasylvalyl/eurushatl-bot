
from aiogram import Bot, Dispatcher, types
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from aiogram.utils import executor

import os
TOKEN = os.getenv("BOT_TOKEN", "YOUR_TOKEN_HERE")  # <-- Бот-токен з .env або змінної оточення

bot = Bot(token=TOKEN)
dp = Dispatcher(bot)

menu = ReplyKeyboardMarkup(resize_keyboard=True)
menu.add(KeyboardButton("📅 Розклад рейсів"), KeyboardButton("🚌 Забронювати місце"))

@dp.message_handler(commands=['start'])
async def start(message: types.Message):
    await message.answer("Вітаємо в Euroshatl! Оберіть дію:", reply_markup=menu)

@dp.message_handler(lambda message: message.text == "📅 Розклад рейсів")
async def schedule(message: types.Message):
    await message.answer(
        "🛣 Рейси:

"
        "🇺🇦 Україна – 🇩🇪 Німеччина: Пн, Ср, Пт
"
        "🇩🇪 Німеччина – 🇺🇦 Україна: Нд, Вт, Чт
"
        "💶 Ціна: від 220€"
    )

@dp.message_handler(lambda message: message.text == "🚌 Забронювати місце")
async def book(message: types.Message):
    await message.answer("Щоб забронювати місце, надішліть:

"
                         "📍 Пункт відправлення
"
                         "📍 Пункт прибуття
"
                         "📅 Дату
"
                         "👤 Ім’я та номер телефону")

@dp.message_handler()
async def order_request(message: types.Message):
    admin_id = message.from_user.id
    await message.forward(admin_id)
    await message.reply("✅ Вашу заявку прийнято! З вами зв’яжемося найближчим часом.")

if __name__ == '__main__':
    executor.start_polling(dp)
