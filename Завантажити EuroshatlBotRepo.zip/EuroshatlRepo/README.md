
# Euroshatl Telegram Bot

Цей бот дозволяє показувати розклад міжнародних пасажирських рейсів і приймати заявки на бронювання місць.

## 🔧 Встановлення

1. Клонувати або завантажити репозиторій.
2. Створити файл `.env` на основі `.env.example` та вставити свій токен.
3. Встановити залежності:

```
pip install -r requirements.txt
```

4. Запуск:

```
python main.py
```

## 🌐 Деплой на Render

- Build command: `pip install -r requirements.txt`
- Start command: `python main.py`
- Environment Variable: `BOT_TOKEN=тут_твій_токен`
